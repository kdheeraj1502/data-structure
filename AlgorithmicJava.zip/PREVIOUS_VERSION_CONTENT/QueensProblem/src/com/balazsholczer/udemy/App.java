package com.balazsholczer.udemy;

public class App {

	public static void main(String[] args) {
		
		QueensProblem problem = new QueensProblem(100);
		problem.solve();
		
	}
}
